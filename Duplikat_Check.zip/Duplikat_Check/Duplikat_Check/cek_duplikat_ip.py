#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cek unique IP dari file .txt (STRICT ONLY + auto + hacker-style progress)
- Mode: STRICT (satu baris harus hanya IP valid)
- Output: <nama_file_input>_unique.txt
"""

from collections import OrderedDict, Counter
import ipaddress
import os
import sys
from datetime import datetime

# ====== Warna (pakai colorama jika ada) ======
RESET = ""
BOLD = ""
DIM = ""
RED = ""
GREEN = ""
YELLOW = ""
CYAN = ""
MAG = ""

try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init()
    RESET = Style.RESET_ALL
    BOLD = Style.BRIGHT
    DIM = Style.DIM
    RED = Fore.RED
    GREEN = Fore.GREEN
    YELLOW = Fore.YELLOW
    CYAN = Fore.CYAN
    MAG = Fore.MAGENTA
except Exception:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    CYAN = "\033[36m"
    MAG = "\033[35m"

SPINNER_FRAMES = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]

def banner():
    print(f"""{DIM}
  ┌───────────────────────────────────────────────┐
  │ {BOLD}{CYAN}UNIQUE IP EXTRACTOR — STRICT MODE — AUTO{RESET}{DIM} │
  └───────────────────────────────────────────────┘{RESET}
""")

def is_ip(s: str) -> bool:
    try:
        ipaddress.ip_address(s)
        return True
    except Exception:
        return False

def progress_bar(prefix: str, i: int, total: int, width: int = 30, frame_idx: int = 0):
    pct = 0.0 if total <= 0 else min(max(i / total, 0.0), 1.0)
    filled = int(width * pct)
    bar = f"{GREEN}{'#'*filled}{RESET}{DIM}{'.'*(width - filled)}{RESET}"
    spinner = SPINNER_FRAMES[frame_idx % len(SPINNER_FRAMES)]
    msg = f"\r{DIM}[{spinner}]{RESET} {prefix} [{bar}] {BOLD}{int(pct*100):3d}%{RESET}"
    sys.stdout.write(msg)
    sys.stdout.flush()

def main():
    banner()
    path = input(f"{BOLD}Masukkan File TXT:{RESET} ").strip()

    if not path:
        print(f"{RED}Path kosong.{RESET}")
        return
    if not os.path.isfile(path):
        print(f"{RED}File '{path}' tidak ditemukan.{RESET}")
        return

    base, _ = os.path.splitext(path)
    out_unique = f"{base}_unique.txt"

    try:
        with open(path, "r", encoding="utf-8") as f:
            total_lines = sum(1 for _ in f)
    except Exception as e:
        print(f"{RED}Gagal membaca file: {e}{RESET}")
        return

    seen = OrderedDict()
    counts = Counter()
    non_ip = 0
    processed = 0
    frame = 0

    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                processed += 1
                line = raw.strip()
                if not line or line.startswith("#"):
                    progress_bar("Memindai", processed, total_lines, frame_idx=frame)
                    frame += 1
                    continue

                if is_ip(line):
                    counts[line] += 1
                    if line not in seen:
                        seen[line] = None
                else:
                    non_ip += 1

                if processed % 50 == 0:
                    progress_bar("Memindai", processed, total_lines, frame_idx=frame)
                    frame += 1

        progress_bar("Memindai", total_lines, total_lines, frame_idx=frame)
        print()
    except Exception as e:
        print(f"\n{RED}Terjadi error saat parsing: {e}{RESET}")
        return

    try:
        with open(out_unique, "w", encoding="utf-8") as fu:
            fu.write(f"# Unique IP dari: {os.path.basename(path)}\n")
            fu.write(f"# Generated at : {datetime.now().isoformat(timespec='seconds')}\n")
            fu.write(f"# Mode strict  : True\n\n")
            for ip in seen.keys():
                fu.write(f"{ip}\n")
    except Exception as e:
        print(f"{RED}Gagal menyimpan file unique: {e}{RESET}")
        return

    total_valid = sum(counts.values())
    unique_count = len(seen)
    dupe_entries = total_valid - unique_count

    print(f"{BOLD}{CYAN}Selesai.{RESET}")
    print(f"  File input     : {YELLOW}{path}{RESET}")
    print(f"  Mode strict    : {GREEN}True{RESET}")
    print(f"  Total baris    : {YELLOW}{total_lines}{RESET}")
    print(f"  Entri IP valid : {YELLOW}{total_valid}{RESET}")
    print(f"  Unique IP      : {YELLOW}{unique_count}{RESET}")
    print(f"  Entri duplikat : {YELLOW}{dupe_entries}{RESET}")
    print(f"\n{GREEN}File unique disimpan otomatis ke: {BOLD}{out_unique}{RESET}")

if __name__ == "__main__":
    main()
